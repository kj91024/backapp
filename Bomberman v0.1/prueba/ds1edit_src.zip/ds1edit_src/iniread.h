#ifndef _INIREAD_H_

#define _INIREAD_H_

void ini_read (char * ininame);

#endif
