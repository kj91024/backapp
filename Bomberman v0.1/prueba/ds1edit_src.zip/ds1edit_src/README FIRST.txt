This program use the Allegro Library. I used the version 4.0.3
The Allegro homepage is at http://www.talula.demon.co.uk/allegro/

It can be compiled with Microsoft VC6, and it should be compiled with DJGPP too.

The mpq\ directory is my modification of the 'Sample Console App source code'
at http://www.angelfire.com/sc/mpq/ Big thanks to Tom Amigo to have released
these sources. It's a really usefull piece of code. I needed very few minor
modifications to be able to compile them under DJGPP.

To compile my prog, you need to make a new project with all .c and all .h,
and don't forget to link the Allegro library.

With VC6, important points :
   * file / new / projects / win32 console application
   * platforms : win32
   * an empty project

   * add all .c and .h, and don't forget the ones in mpq\ directory

   * project / settings, tab 'link', in object/library modules,
     add 'alleg.lib' (you need to have installed it of course).

You shouldn't have any warnings or errors.