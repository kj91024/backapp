#ifndef _DT1_DRAW_H_

#define _DT1_DRAW_H_

void draw_sub_tile_isometric (BITMAP * dst, int x0, int y0, UBYTE * data, int length);
void draw_sub_tile_normal    (BITMAP * dst, int x0, int y0, UBYTE * data, int length);

#endif
