#ifndef _WMSG_H_

#define _WMSG_H_

int wmsg_main(WMSG_S * wmsg);

#endif
