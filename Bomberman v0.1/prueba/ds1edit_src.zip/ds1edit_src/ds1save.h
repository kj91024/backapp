#ifndef _DS1SAVE_H_

#define _DS1SAVE_H_

void ds1_save(int ds1_idx, int is_tmp_file);

#endif
