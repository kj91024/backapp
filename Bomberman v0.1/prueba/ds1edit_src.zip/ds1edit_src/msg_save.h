#ifndef _MSG_SAVE_H_

#define _MSG_SAVE_H_

int msg_save_main(void);

#endif
