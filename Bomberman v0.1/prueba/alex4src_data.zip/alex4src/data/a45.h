/* Allegro datafile object indexes, produced by grabber v4.0.2, MSVC.s */
/* Datafile: c:\Documents and Settings\Johan\My Documents\game development\projects\alex4\data\a45.dat */
/* Date: Mon May 19 13:32:25 2003 */
/* Do not hand edit! */

#define aaa_F1SHIP                       0        /* BMP  */
#define BG1                              1        /* BMP  */
#define BULLET01                         2        /* BMP  */
#define BULLET02                         3        /* BMP  */
#define BULLET03                         4        /* BMP  */
#define BULLET04                         5        /* BMP  */
#define BULLET05                         6        /* BMP  */
#define BULLET06                         7        /* BMP  */
#define BULLET07                         8        /* BMP  */
#define BULLET08                         9        /* BMP  */
#define BULLET_HIT                       10       /* BMP  */
#define ENEMY01                          11       /* BMP  */
#define ENEMY02                          12       /* BMP  */
#define ENEMY03                          13       /* BMP  */
#define ENEMY04                          14       /* BMP  */
#define ENEMY05                          15       /* BMP  */
#define ENEMY06                          16       /* BMP  */
#define ENEMY07                          17       /* BMP  */
#define ENEMY08                          18       /* BMP  */
#define ENEMY09                          19       /* BMP  */
#define ENEMY10                          20       /* BMP  */
#define ENEMY11                          21       /* BMP  */
#define ENEMY12                          22       /* BMP  */
#define ENEMY13                          23       /* BMP  */
#define ENEMY14                          24       /* BMP  */
#define ENEMY15                          25       /* BMP  */
#define ENEMY16                          26       /* BMP  */
#define POWERUP                          27       /* BMP  */
#define SHIP                             28       /* BMP  */
#define SPACE_FONT                       29       /* FONT */
#define SPACEMOD                         30       /* MOD  */
#define ST_LIFE                          31       /* BMP  */
#define ST_STAR_OFF                      32       /* BMP  */
#define ST_STAR_ON                       33       /* BMP  */
#define STATUSBAR                        34       /* BMP  */

